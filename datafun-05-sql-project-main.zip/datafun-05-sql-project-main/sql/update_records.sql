-- update_records.sql

UPDATE songs
SET duration = '4:30'
WHERE title = 'Let It Be';