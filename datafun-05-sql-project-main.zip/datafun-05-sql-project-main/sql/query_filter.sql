-- query_filter.sql

SELECT * FROM artists
WHERE genre = 'Pop';