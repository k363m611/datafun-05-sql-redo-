-- delete_records.sql

DELETE FROM songs
WHERE title = 'Rocket Man';