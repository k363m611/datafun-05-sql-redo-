-- query_sorting.sql

SELECT * FROM Songs
ORDER BY release_year DESC;